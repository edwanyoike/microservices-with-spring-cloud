package com.utility.configserverms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigservermsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigservermsApplication.class, args);
	}

}
